package com.rupesh.jscollage.ui.home;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;


import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;


import com.rupesh.jscollage.R;
import com.smarteist.autoimageslider.DefaultSliderView;
import com.smarteist.autoimageslider.IndicatorAnimations;
import com.smarteist.autoimageslider.SliderAnimations;
import com.smarteist.autoimageslider.SliderLayout;


public class HomeFragment extends Fragment {

    private SliderLayout sliderLayout;

    private ImageView map;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view=inflater.inflate(R.layout.fragment_home, container, false);

        sliderLayout = view.findViewById(R.id.slider);
        sliderLayout.setIndicatorAnimation(IndicatorAnimations.FILL);
        sliderLayout.setSliderTransformAnimation(SliderAnimations.SIMPLETRANSFORMATION);
        sliderLayout.setScrollTimeInSec(1);

        setSliderView();

        map = view.findViewById(R.id.map);
        map.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openMap();
            }
        });

        return view;

    }

    private void openMap() {
        Uri uri = Uri.parse("geo:0, 0?q=Government  J.S. Murarka Multiple Campus Lahan Siraha");
        Intent intent = new Intent(Intent.ACTION_VIEW,uri);
        intent.setPackage("com.google.android.apps.maps");
        startActivity(intent);
    }


    private void setSliderView() {
        for (int i = 0; i < 5; i++) {
            DefaultSliderView sliderView = new DefaultSliderView(getContext());

            switch (i) {
                case 0:
                    sliderView.setImageUrl("https://firebasestorage.googleapis.com/v0/b/my-cl-88013.appspot.com/o/Teachers%2F%5BB%40de1e4df.jpg?alt=media&token=e6211b11-67b7-4e9c-85bf-bd38905bff6b");
                             break;

                case 1:
                    sliderView.setImageUrl("https://firebasestorage.googleapis.com/v0/b/my-cl-88013.appspot.com/o/Teachers%2F%5BB%40cf0f527.jpg?alt=media&token=50052236-5363-4888-aa80-d9e8803fa2f0");
                    break;

                case 2:
                    sliderView.setImageUrl("https://firebasestorage.googleapis.com/v0/b/my-cl-88013.appspot.com/o/Teachers%2F%5BB%404f98f32.jpg?alt=media&token=b8b9fcad-87e0-4b53-928d-1c9e3a7a0afa");
                    break;

                case 3:
                    sliderView.setImageUrl("https://firebasestorage.googleapis.com/v0/b/my-cl-88013.appspot.com/o/gallery%2F%5BB%4081f31dfjpg?alt=media&token=6204cfed-3dff-4b69-bb12-22dd215eded9");
                    break;

                case 4:
                    sliderView.setImageUrl("https://firebasestorage.googleapis.com/v0/b/my-cl-88013.appspot.com/o/gallery%2F%5BB%40d6691b0jpg?alt=media&token=3a8666a4-7d2c-4111-87ca-cb20bf04a8f6");
                    break;
            }
            sliderView.setImageScaleType(ImageView.ScaleType.CENTER_CROP);

            sliderLayout.addSliderView(sliderView);
        }
    }
}