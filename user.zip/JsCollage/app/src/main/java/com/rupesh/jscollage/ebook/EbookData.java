package com.rupesh.jscollage.ebook;

public class EbookData {

    private String name,pdfUri,pdfUrl;

    public EbookData() {
    }


    public EbookData(String name, String pdfUri) {
        this.name = name;
        this.pdfUri = pdfUri;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getPdfUrl() {
        return pdfUrl;
    }

    public void setPdfUrl(String pdfUrl) {
        this.pdfUrl = pdfUrl;
    }


}
